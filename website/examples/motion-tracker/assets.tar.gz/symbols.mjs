export default {
  tracker_colors: 0x3fc92f80,
  tracker_frame_sequence: 0x3fc92f7c,
  tracker_model_error: 0x3fc92f74,
  tracker_pixels: 0x3fc92fa0,
  tracker_touch_input: 0x3fca4c48,
  tracker_touch_reads: 0x3fc92f78,
};
